-- AlterTable
ALTER TABLE `Book` ADD COLUMN `emprestado` BOOLEAN NOT NULL DEFAULT false;
