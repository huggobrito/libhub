-- AlterTable
ALTER TABLE `Schedule` ADD COLUMN `tipo` VARCHAR(191) NULL;
