-- AlterTable
ALTER TABLE `Schedule` ADD COLUMN `devolvido` BOOLEAN NOT NULL DEFAULT false;
