-- AlterTable
ALTER TABLE `Loan` ADD COLUMN `devolvido` BOOLEAN NOT NULL DEFAULT false;
